import MainController from './main.controller';

export default {
  MainController
}