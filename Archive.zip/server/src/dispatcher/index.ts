/**
 * Import dispatcher mediums
 */
import twilio from './twilio.dispatcher';

export default {
    sms: twilio.sms
}