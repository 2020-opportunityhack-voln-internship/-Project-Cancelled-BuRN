import routing from './routing.helper';

export default {
    routing
}