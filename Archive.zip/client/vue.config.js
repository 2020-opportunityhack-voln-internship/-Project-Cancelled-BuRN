// module.exports = {
//   pluginOptions: {
//     webpackBundleAnalyzer: {
//       openAnalyzer: true,
//     },
//   },
// };
